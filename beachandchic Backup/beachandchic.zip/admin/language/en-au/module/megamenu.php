<?php
// Heading
$_['heading_title']         = 'Megamenu';

$_['text_module']           = 'Modules';
$_['text_success']          = 'Success: You have modified megamenu module!';
$_['text_edit']             = 'Edit Megamenu Module';

$_['text_megamenu']         = 'Megamenu';
$_['text_3level']           = '3 Level Menu';
$_['text_current_tab']      = 'Same Winodow';
$_['text_new_tab']          = 'New Winodow';

//
$_['heading_categories']    = 'Categories';
$_['heading_products']      = 'Products';
$_['heading_brands']        = 'Brands';
$_['heading_custom_link']   = 'Custome Links';
$_['heading_custom_block_1']  = 'Block 1';
$_['heading_custom_block_2']  = 'Block 2';
$_['heading_custom_block_3']  = 'Block 3';
$_['heading_information']     = 'Information';
$_['heading_contactus']       = 'Contact Us';


// Entry
$_['entry_homepage']        = 'Home Page link';
$_['entry_home_title']      = 'Home title';
$_['entry_category_status'] = 'Category Status';
$_['entry_category_title']  = 'Category Title';
$_['entry_category_style']  = 'Category Display Style';
$_['entry_category_image']  = 'Show category images';
$_['entry_product_status']  = 'Show Products';
$_['entry_product_title']   = 'Product Title';
$_['entry_product_name']    = 'Name';
$_['entry_product_image']   = 'Image';
$_['entry_product_price']   = 'Price';
$_['entry_product_rating']  = 'Rating';
$_['entry_product']         = 'Products <small>(autocomplete)</small>';

$_['entry_brand_status']    = 'Show Brands';
$_['entry_brand_title']     = 'Brand Title';

$_['entry_custom_link']     = 'Link';
$_['entry_custom_show']     = 'Show';
$_['entry_custom_title']    = 'Title';
$_['entry_custom_url']      = 'Url';
$_['entry_custom_open']     = 'Open';

$_['entry_block_status']    = 'Block Status';
$_['entry_block_name']      = 'Block Title';
$_['entry_custom_html']     = 'Block Content';

$_['entry_info_status']       = 'Show Information';
$_['entry_contactus_status']  = 'Show Contact Us';
$_['entry_custom_status']  	  = 'Show Custom links';






// Error
$_['error_permission'] = 'Warning: You do not have permission to modify megamenu module!';