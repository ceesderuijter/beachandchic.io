<?php

// Heading
$_['heading_title']    = '<b>Revolution Slider </b>';

// Text
$_['text_success']     = 'Success: You have modified module Revolution Slider!';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify module Revolution Slider!';

?>