<?php

#########################################################################################
## Open Cart Module:  APPLY COUPONS / GIFT VOUCHERS / REWARDS POINTS ON CHECKOUT STEPS ##
##-------------------------------------------------------------------------------------##
## Copyright © 2014 MB "Programanija" All rights reserved.                             ##
## http://www.opencartextensions.eu						                               ##
## http://www.extensionsmarket.com 						                               ##
##-------------------------------------------------------------------------------------##
## Permission is hereby granted, when purchased, to  use this                          ##
## mod on one domain. This mod may not be reproduced, copied,                          ##
## redistributed, published and/or sold.				                               ##
##-------------------------------------------------------------------------------------##
## Violation of these rules will cause loss of future mod                              ##
## updates and account deletion				      			                           ##
#########################################################################################

// Heading
$_['heading_title']    = '<strong>Coupons / Gift Vouchers / Reward Points on Checkout<br /></strong>More extensions at [<a href="http://www.opencartextensions.eu" target="_blank">www.opencartextensions.eu</a>]';

$_['heading_title_m']  = 'Coupons / Gift Vouchers / Reward Points on Checkout';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified Coupons / Gift Vouchers / Reward Points on Checkout module!';
$_['text_enabled']     = 'Enabled';
$_['text_disabled']    = 'Disabled';
$_['text_edit']        = 'Edit Coupons / Gift Vouchers / Reward Points on Checkout';

//Help
$_['help_coupon']      = 'Check the box if you want to display the Coupon box on checkout steps.';
$_['help_voucher']     = 'Check the box if you want to display the Gift Voucher box on checkout steps.';
$_['help_reward']      = 'Check the box if you want to display the Reward Points box on checkout steps.<br>Note: The box will be visible if user has any points and if there is at least one item in the cart that can be purchased with Reward Points.';
    
    
// Entry
$_['entry_coupon']  = 'Show Coupons Box';
$_['entry_voucher'] = 'Show Vouchers Box';
$_['entry_reward']  = 'Show Reward Box';
$_['entry_status']  = 'Status';



// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Coupons / Gift Vouchers / Reward Points on Checkout module!';

?>