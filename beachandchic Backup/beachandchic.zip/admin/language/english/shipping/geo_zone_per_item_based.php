<?php
// Heading
$_['heading_title']    = 'Geo Zone (Per Item) Based Shipping';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Success: You have modified regional rate shipping!';
$_['text_edit'] = 'Edit Geo Zone (Per Item) Based Shipping';

// Entry
$_['entry_heading'] = "Heading:";
$_['entry_tax_class']  = 'Tax Class:';
$_['entry_status']     = 'Status:';
$_['entry_sort_order'] = 'Sort Order:';
$_['entry_per_item_cost']   = 'Per Item cost:';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify weight based shipping!';
?>