<?php

class ControllerShippingGeoZonePerItemBased extends Controller {

    private $error = array();

    public function index() {
        $this->language->load('shipping/geo_zone_per_item_based');

        $this->document->setTitle($this->language->get('heading_title'));

        $this->load->model('setting/setting');
        $this->load->model('localisation/country');
        $this->load->model('localisation/tax_class');
        $this->load->model('localisation/geo_zone');

        if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {

            $this->model_setting_setting->editSetting('geo_zone_per_item_based', $this->request->post);

            $this->session->data['success'] = $this->language->get('text_success');

           $this->response->redirect($this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL'));
        }

        $data['heading_title'] = $this->language->get('heading_title');

        $data['text_none'] = $this->language->get('text_none');
        $data['text_enabled'] = $this->language->get('text_enabled');
        $data['text_disabled'] = $this->language->get('text_disabled');
        $data['text_edit'] = $this->language->get('text_edit');

        $data['entry_heading'] = $this->language->get('entry_heading');
        $data['entry_tax_class'] = $this->language->get('entry_tax_class');
        $data['entry_per_item_cost'] = $this->language->get('entry_per_item_cost');
        $data['entry_status'] = $this->language->get('entry_status');
        $data['entry_sort_order'] = $this->language->get('entry_sort_order');

        $data['button_save'] = $this->language->get('button_save');
        $data['button_cancel'] = $this->language->get('button_cancel');


        $data['tab_general'] = $this->language->get('tab_general');


        if (isset($this->error['warning'])) {
            $data['error_warning'] = $this->error['warning'];
        } else {
            $data['error_warning'] = '';
        }

        $data['breadcrumbs'] = array();

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_home'),
            'href' => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => false
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('text_shipping'),
            'href' => $this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['breadcrumbs'][] = array(
            'text' => $this->language->get('heading_title'),
            'href' => $this->url->link('shipping/geo_zone_per_item_based', 'token=' . $this->session->data['token'], 'SSL'),
            'separator' => ' :: '
        );

        $data['action'] = $this->url->link('shipping/geo_zone_per_item_based', 'token=' . $this->session->data['token'], 'SSL');

        $data['cancel'] = $this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL');

        $data['token'] = $this->session->data['token'];



        $data['geo_zones'] = $this->model_localisation_geo_zone->getGeoZones();
        $data['countries'] = $this->model_localisation_country->getCountries();
        $data['tax_classes'] = $this->model_localisation_tax_class->getTaxClasses();

        if (isset($this->request->post['geo_zone_per_item_based_tax_class_id'])) {
            $data['geo_zone_per_item_based_tax_class_id'] = $this->request->post['geo_zone_per_item_based_tax_class_id'];
        } else {
            $data['geo_zone_per_item_based_tax_class_id'] = $this->config->get('geo_zone_per_item_based_tax_class_id');
        }

        if (isset($this->request->post['geo_zone_per_item_based_heading'])) {
            $data['geo_zone_per_item_based_heading'] = $this->request->post['geo_zone_per_item_based_heading'];
        } else {
            $data['geo_zone_per_item_based_heading'] = $this->config->get('geo_zone_per_item_based_heading');
        }

        if (isset($this->request->post['geo_zone_per_item_based_status'])) {
            $data['geo_zone_per_item_based_status'] = $this->request->post['geo_zone_per_item_based_status'];
        } else {
            $data['geo_zone_per_item_based_status'] = $this->config->get('geo_zone_per_item_based_status');
        }

        if (isset($this->request->post['geo_zone_per_item_based_sort_order'])) {
            $data['geo_zone_per_item_based_sort_order'] = $this->request->post['geo_zone_per_item_based_sort_order'];
        } else {
            $data['geo_zone_per_item_based_sort_order'] = $this->config->get('geo_zone_per_item_based_sort_order');
        }

        $geo_zone_cost_arr = $this->config->get('geo_zone_per_item_based_cost');
        foreach ($this->model_localisation_geo_zone->getGeoZones() as $key) {
            if (isset($this->request->post['geo_zone_per_item_based_cost'][$key['geo_zone_id']]['cost'])) {
                $geo_zone_cost_array[$key['geo_zone_id']] = $this->request->post['geo_zone_cost'][$key];
            } else {
                $geo_zone_cost_array[$key['geo_zone_id']] = isset($geo_zone_cost_arr[$key['geo_zone_id']]) ? $geo_zone_cost_arr[$key['geo_zone_id']] : array("cost" => 0.00, "status" => 0);
            }
        }

        $data['geo_zone_per_item_based_cost'] = $geo_zone_cost_array;


        $data['header'] = $this->load->controller('common/header');
        $data['column_left'] = $this->load->controller('common/column_left');
        $data['footer'] = $this->load->controller('common/footer');

        $this->response->setOutput($this->load->view('shipping/geo_zone_per_item_based.tpl', $data));
    }

    protected function validate() {
        if (!$this->user->hasPermission('modify', 'shipping/geo_zone_per_item_based')) {
            $this->error['warning'] = $this->language->get('error_permission');
        }

        if (!$this->error) {
            return true;
        } else {
            return false;
        }
    }

}

?>