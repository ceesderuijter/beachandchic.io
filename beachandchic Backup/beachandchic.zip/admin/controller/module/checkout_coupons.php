<?php 
#########################################################################################
## Open Cart Module:  APPLY COUPONS / GIFT VOUCHERS / REWARDS POINTS ON CHECKOUT STEPS ##
##-------------------------------------------------------------------------------------##
## Copyright © 2014 MB "Programanija" All rights reserved.                             ##
## http://www.opencartextensions.eu						                               ##
## http://www.extensionsmarket.com 						                               ##
##-------------------------------------------------------------------------------------##
## Permission is hereby granted, when purchased, to  use this                          ##
## mod on one domain. This mod may not be reproduced, copied,                          ##
## redistributed, published and/or sold.				                               ##
##-------------------------------------------------------------------------------------##
## Violation of these rules will cause loss of future mod                              ##
## updates and account deletion				      			                           ##
#########################################################################################

class ControllerModuleCheckoutCoupons extends Controller {
	
	private $error = array(); 

	public function index() {
		
		$this->load->language('module/checkout_coupons');

		$this->document->setTitle($this->language->get('heading_title_m'));
		
		$this->load->model('setting/setting');
			
		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('checkout_coupons', $this->request->post);				
			
			$this->session->data['success'] = $this->language->get('text_success');
			
			$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));

		}
		
		$text_array = array('heading_title','heading_title_m','text_edit','text_enabled','text_disabled',
                            'button_save','button_cancel','entry_status', 'entry_coupon','help_coupon','entry_voucher','help_voucher',
                            'entry_reward','help_reward');
		
		foreach($text_array as $key){
			$data[$key] = $this->language->get($key);
		}
		
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}


  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL')
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('heading_title_m'),
			'href'      => $this->url->link('module/checkout_coupons', 'token=' . $this->session->data['token'], 'SSL')
   		);
				
		$data['action'] = $this->url->link('module/checkout_coupons', 'token=' . $this->session->data['token'], 'SSL');
		
		$data['cancel'] = $this->url->link('module/checkout_coupons', 'token=' . $this->session->data['token'], 'SSL');
		
        
		if (isset($this->request->post['checkout_coupons_coupon_box'])) {
			$data['checkout_coupons_coupon_box'] = $this->request->post['checkout_coupons_coupon_box'];
		} else {
			$data['checkout_coupons_coupon_box'] = $this->config->get('checkout_coupons_coupon_box');
		}
		
        if (isset($this->request->post['checkout_coupons_voucher_box'])) {
			$data['checkout_coupons_voucher_box'] = $this->request->post['checkout_coupons_voucher_box'];
		} else {
			$data['checkout_coupons_voucher_box'] = $this->config->get('checkout_coupons_voucher_box');
		}
		
        
        if (isset($this->request->post['checkout_coupons_reward_box'])) {
			$data['checkout_coupons_reward_box'] = $this->request->post['checkout_coupons_reward_box'];
		} else {
			$data['checkout_coupons_reward_box'] = $this->config->get('checkout_coupons_reward_box');
		}
		
		
		if (isset($this->request->post['checkout_coupons_status'])) {
			$data['checkout_coupons_status'] = $this->request->post['checkout_coupons_status'];
		} else {
			$data['checkout_coupons_status'] = $this->config->get('checkout_coupons_status');
		}


		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('module/checkout_coupons.tpl', $data));
	}

	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/checkout_coupons')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		
		return !$this->error;
		
	}	
}
?>