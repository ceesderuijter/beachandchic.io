<?php
class ControllerModuleMegamenu extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('module/megamenu');

		$this->document->setTitle($this->language->get('heading_title'));

		$this->load->model('setting/setting');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_setting_setting->editSetting('megamenu', $this->request->post);

			$this->session->data['success'] = $this->language->get('text_success');

			//$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL'));
			$this->response->redirect($this->url->link('module/megamenu', 'token=' . $this->session->data['token'], 'SSL'));
		}

		$data['heading_title'] = $this->language->get('heading_title');
		
		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_yes'] = $this->language->get('text_yes');
		$data['text_no'] = $this->language->get('text_no');
		$data['text_current_tab'] = $this->language->get('text_current_tab');
		$data['text_new_tab'] = $this->language->get('text_new_tab');
		
		
		$data['text_megamenu']  = $this->language->get('text_megamenu');
		$data['text_3level'] = $this->language->get('text_3level');
		
		$data['heading_categories'] = $this->language->get('heading_categories');
		$data['heading_products'] = $this->language->get('heading_products');
		$data['heading_brands'] = $this->language->get('heading_brands');
		$data['heading_custom_link'] = $this->language->get('heading_custom_link');
		$data['heading_custom_block_1'] = $this->language->get('heading_custom_block_1');
		$data['heading_custom_block_2'] = $this->language->get('heading_custom_block_2');
		$data['heading_custom_block_3'] = $this->language->get('heading_custom_block_3');
		$data['heading_information'] = $this->language->get('heading_information');
		$data['heading_contactus'] = $this->language->get('heading_contactus');
		
		$data['entry_homepage'] = $this->language->get('entry_homepage');
		$data['entry_home_title'] = $this->language->get('entry_home_title');
		$data['entry_category_status'] = $this->language->get('entry_category_status');
		$data['entry_category_title'] = $this->language->get('entry_category_title');
		$data['entry_category_style'] = $this->language->get('entry_category_style');
		$data['entry_category_image'] = $this->language->get('entry_category_image');
		$data['entry_product_status'] = $this->language->get('entry_product_status');
		$data['entry_product_title'] = $this->language->get('entry_product_title');	
		$data['entry_product_setting'] = $this->language->get('entry_product_setting');
		$data['entry_product_name'] = $this->language->get('entry_product_name');
		$data['entry_product_image'] = $this->language->get('entry_product_image');
		$data['entry_product_price'] = $this->language->get('entry_product_price');
		$data['entry_product_rating'] = $this->language->get('entry_product_rating');
		$data['entry_product'] = $this->language->get('entry_product');
		$data['entry_brand_status'] = $this->language->get('entry_brand_status');
		$data['entry_brand_title'] = $this->language->get('entry_brand_title');
		$data['entry_brand_logo'] = $this->language->get('entry_brand_logo');
		$data['entry_custom_link'] = $this->language->get('entry_custom_link');
		$data['entry_custom_show'] = $this->language->get('entry_custom_show');
		$data['entry_custom_title'] = $this->language->get('entry_custom_title');
		$data['entry_custom_url'] = $this->language->get('entry_custom_url');
		$data['entry_custom_open'] = $this->language->get('entry_custom_open');
		$data['entry_block_status'] = $this->language->get('entry_block_status');
		$data['entry_block_title'] = $this->language->get('entry_block_title');
		$data['entry_block_name'] = $this->language->get('entry_block_name');
		$data['entry_custom_html'] = $this->language->get('entry_custom_html');
		$data['entry_info_status'] = $this->language->get('entry_info_status');		
		$data['entry_contactus_status'] = $this->language->get('entry_contactus_status');
		$data['entry_custom_status'] = $this->language->get('entry_custom_status');

		$data['button_add'] = $this->language->get('button_add');
		$data['button_remove'] = $this->language->get('button_remove');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		
		$data['token'] = $this->session->data['token'];

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_module'),
			'href' => $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('module/megamenu', 'token=' . $this->session->data['token'], 'SSL')
		);

		$data['action'] = $this->url->link('module/megamenu', 'token=' . $this->session->data['token'], 'SSL');

		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], 'SSL');

		$this->load->model('localisation/language');

		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		// Array 
		$data['megamenu_homes']	    = array(
						    'text' => 'Text',
						    'icon' => 'Icon'
						    //'dontshow' => 'Don\'t show'
					      );
				
		
		// HOME PAGE ICONS
		
		if (isset($this->request->post['megamenu_home_style'])) {
			$data['megamenu_home_style'] = $this->request->post['megamenu_home_style'];
		} else {
			$data['megamenu_home_style'] = $this->config->get('megamenu_home_style');
		}
		
		// CATEGORIES
		
		if (isset($this->request->post['megamenu_category_status'])) {
			$data['megamenu_category_status'] = $this->request->post['megamenu_category_status'];
		} else {
			$data['megamenu_category_status'] = $this->config->get('megamenu_category_status');
		}
		
		// Array 
		$data['megamenu_category_style'] = array(
						    'opencart' => 'OpenCart',
						    'vertical' => 'Vertical',
						    'horizontal' => 'Horizontal'
					      );
				
		if (isset($this->request->post['megamenu_category_style'])) {
			$data['categories_style'] = $this->request->post['megamenu_category_style'];
		} else {
			$data['categories_style'] = $this->config->get('megamenu_category_style');
		}
		
		if (isset($this->request->post['megamenu_menu'])) {
			$data['megamenu_menu'] = $this->request->post['megamenu_menu'];
		} else {
			$data['megamenu_menu'] = $this->config->get('megamenu_menu');
		}

		/*if (isset($this->request->post['megamenu_category_image'])) {
			$data['megamenu_category_image'] = $this->request->post['megamenu_category_image'];
		} else {
			$data['megamenu_category_image'] = $this->config->get('megamenu_category_image');
		}*/
		
		// PRODUCTS 
		if (isset($this->request->post['megamenu_product_status'])) {
			$data['megamenu_product_status'] = $this->request->post['megamenu_product_status'];
		} else {
			$data['megamenu_product_status'] = $this->config->get('megamenu_product_status');
		}

		if (isset($this->request->post['megamenu_product_name'])) {
			$data['megamenu_product_name'] = $this->request->post['megamenu_product_name'];
		} else {
			$data['megamenu_product_name'] = $this->config->get('megamenu_product_name');
		}

		if (isset($this->request->post['megamenu_product_image'])) {
			$data['megamenu_product_image'] = $this->request->post['megamenu_product_image'];
		} else {
			$data['megamenu_product_image'] = $this->config->get('megamenu_product_image');
		}

		if (isset($this->request->post['megamenu_product_price'])) {
			$data['megamenu_product_price'] = $this->request->post['megamenu_product_price'];
		} else {
			$data['megamenu_product_price'] = $this->config->get('megamenu_product_price');
		}

		if (isset($this->request->post['megamenu_product_rating'])) {
			$data['megamenu_product_rating'] = $this->request->post['megamenu_product_rating'];
		} else {
			$data['megamenu_product_rating'] = $this->config->get('megamenu_product_rating');
		}
		
		$this->load->model('catalog/product');
		
		$data['products'] = array();
		
		if (isset($this->request->post['megamenu_product'])) {
			$products = $this->request->post['megamenu_product'];
		} elseif ($this->config->has('megamenu_product')) {
			$products = $this->config->get('megamenu_product');
		} else {
			$products = array();
		}	
		
		if($products){
			foreach ($products as $product_id) {
				$product_info = $this->model_catalog_product->getProduct($product_id);

				if ($product_info) {
					$data['products'][] = array(
						'product_id' => $product_info['product_id'],
						'name'       => $product_info['name']
					);
				}
			}
		}

		
		//  BRANDS
				
		if (isset($this->request->post['megamenu_brand_status'])) {
			$data['megamenu_brand_status'] = $this->request->post['megamenu_brand_status'];
		} else {
			$data['megamenu_brand_status'] = $this->config->get('megamenu_brand_status');
		}
		
		
		//  CUSTOM LINKS
		
		if (isset($this->request->post['megamenu_custom_status'])) {
			$data['megamenu_custom_status'] = $this->request->post['megamenu_custom_status'];
		} else {
			$data['megamenu_custom_status'] = $this->config->get('megamenu_custom_status');
		}		

		
		if (isset($this->request->post['megamenu_custom_option'])) {
			$data['custom_options'] = $this->request->post['megamenu_custom_option'];
		} else {
			$data['custom_options'] = $this->config->get('megamenu_custom_option');
		}
		
		//
		
		 //CUSTOME BLOCKS
		 
		if (isset($this->request->post['megamenu_block1_status'])) {
			$data['megamenu_block1_status'] = $this->request->post['megamenu_block1_status'];
		} else {
			$data['megamenu_block1_status'] = $this->config->get('megamenu_block1_status');
		}

		if (isset($this->request->post['megamenu_block2_status'])) {
			$data['megamenu_block2_status'] = $this->request->post['megamenu_block2_status'];
		} else {
			$data['megamenu_block2_status'] = $this->config->get('megamenu_block2_status');
		}

		if (isset($this->request->post['megamenu_block3_status'])) {
			$data['megamenu_block3_status'] = $this->request->post['megamenu_block3_status'];
		} else {
			$data['megamenu_block3_status'] = $this->config->get('megamenu_block3_status');
		}
		
		 if (isset($this->request->post['megamenu_block'])) {
			$data['megamenu_block'] = $this->request->post['megamenu_block'];
		} else {
			$data['megamenu_block'] = $this->config->get('megamenu_block');
		}
		
		// INFORMATION STATUS
		
		if (isset($this->request->post['megamenu_information_status'])) {
			$data['megamenu_information_status'] = $this->request->post['megamenu_information_status'];
		} else {
			$data['megamenu_information_status'] = $this->config->get('megamenu_information_status');
		}		
		
		// CONTACT STATUS
		if (isset($this->request->post['megamenu_contactus_status'])) {
			$data['megamenu_contactus_status'] = $this->request->post['megamenu_contactus_status'];
		} else {
			$data['megamenu_contactus_status'] = $this->config->get('megamenu_contactus_status');
		}		
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/megamenu.tpl', $data));
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'module/megamenu')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		return !$this->error;
	}
}