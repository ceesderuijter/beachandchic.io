<?php
class ControllerModulePowership extends Controller {
    
	private $error = array(); 
	
	public function install() {
	    $defaultSettings = array(
	    );
	    
		$this->load->model('setting/setting');
		$this->model_setting_setting->editSetting('powership', $defaultSettings);
		
// 		$this->load->model('module/powership');
// 		$this->model_module_powership->install();
		
	}
	
	
	private function generateRandomString($length = 4) {
	    //$characters = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
	    $characters = '23456789abcdefghjkmnpqrstuvwxyz';
	    $randomString = '';
	    for ($i = 0; $i < $length; $i++) {
	        $randomString .= $characters[rand(0, strlen($characters) - 1)];
	    }
	    return $randomString;
	}
	
	
	function getDirContents($dir, &$results = array()){
	    $files = scandir($dir);
	
	    foreach($files as $key => $value){
	        $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
	        if(!is_dir($path)) {
	            $results[] = $path;
	        } else if($value != "." && $value != "..") {
	            $this->getDirContents($path, $results);
	            //$results[] = $path;
	        }
	    }
	
	    return $results;
	}
	
	function startsWith($haystack, $needle) {
	    // search backwards starting from haystack length characters from the end
	    return $needle === "" || strrpos($haystack, $needle, -strlen($haystack)) !== false;
	}
	
	public function index() {
	
	    $module_route = 'module/powership';
	    if(version_compare(VERSION, "2.2.0.0", "le")){ //le  oc22
	        $modules_route = 'extension/module';
	    }else{
	        $modules_route = 'extension/extension';
	    }
	    
	    
		$this->load->language('module/powership');
		
		$this->document->setTitle($this->language->get('heading_title'));
		
		//Load the settings model. You can also add any other models you want to load here.
		$this->load->model('setting/setting');
		
		//Save the settings if the user has submitted the admin form (ie if someone has pressed save).
		if ($this->request->server['REQUEST_METHOD'] == 'POST') {
		    
		    $this->log->write('[powership] method is post ');
		    
			//$this->model_setting_setting->editSetting('powership', $this->request->post);		
			
		    if($this->request->post['method_family'] === 'flat'){
		        
		        if(version_compare(VERSION, '2.3.0.0', 'ge')) {
        		    $selected_skel = "powership_flat_oc2300"; 		            
		        }else if(version_compare(VERSION, '2.2.0.0', 'ge')) {
        		    $selected_skel = "powership_flat_oc2200"; 
		        }else{
        		    $selected_skel = "powership_flat_oc2"; 
		        }
    		    
		    }else if ($this->request->post['method_family'] === 'weight'){
		        if(version_compare(VERSION, '2.3.0.0', 'ge')) {
        		    $selected_skel = "powership_weight_oc2300";
		        }else if(version_compare(VERSION, '2.2.0.0', 'ge')) {
        		    $selected_skel = "powership_weight_oc2200";
		        }else {
        		    $selected_skel = "powership_weight_oc2101"; 		        
		        }
    		    
		    }else if ($this->request->post['method_family'] === 'total'){
		        if(version_compare(VERSION, '2.2.0.0', 'ge')) {
		            $selected_skel = "powership_total_oc2200";
		        }
		    }else if ($this->request->post['method_family'] === 'quantity'){
		        if(version_compare(VERSION, '2.2.0.0', 'lt')) {
        		    $selected_skel = "powership_quantity_oc2101"; 		        
		        }
		    }
		    
		    if(!isset($selected_skel)){
		        $this->session->data['error_msg'] = $this->language->get('This choice is not available');
		        
		        if(version_compare(VERSION, '2.2.0.0') >= 0){
		            $this->response->redirect($this->url->link('module/powership', 'token=' . $this->session->data['token'], true));
		        }else{
		            $this->response->redirect($this->url->link('module/powership', 'token=' . $this->session->data['token'], 'SSL'));
		        }
		    }
		    
		    $HASH = $this->generateRandomString(8);
		    $CAMEL_CASE_CODE = "powership" . $HASH;
		    $LOWER_CASE_CODE = "powership_" . $HASH;
		    
		    //for each file of our skel do:
		    
		    //get content

		    $skel_files = $this->getDirContents(DIR_SYSTEM . "powership_skel/" . $selected_skel);
		    
		    foreach ($skel_files as $skel_file){
		        
		        $original = array();
		        $produced = array();
		        
		        $original['file_absolute_path'] = $skel_file;
		        $original['file_content'] = file_get_contents($original['file_absolute_path']);
		        
		        $find = array(
	                "__DISPLAY_NAME__", 
                    "__LOWER_CASE_CODE__",
		            "__CAMEL_CASE_CODE__",
		            "__HASH_CODE__"      ,
		            "powership-oc2-extension"     ,
		            "dev@smshare.fr - https://www.prowebtec.com"         ,
		            "2.5.1"  ,
		            "3.4.1"        ,
		        );
		        $replace = array(
	                "__DISPLAY_NAME__"    => $this->request->post['display_name'],
	                "__LOWER_CASE_CODE__" => $LOWER_CASE_CODE,
	                "__CAMEL_CASE_CODE__" => $CAMEL_CASE_CODE,
	                "__HASH_CODE__"       => $HASH,
		            "powership-oc2-extension"      => $this->request->post['display_name'],
		            "dev@smshare.fr - https://www.prowebtec.com"          => "dev@smshare.fr - http://www.smshare.fr",
		            "2.5.1"   => "2.5.1",
		            "3.4.1"         => "1.0.0",
		        );
		        
    		    /*
    		     * do replacment of all variables in content
    		     */
		        $produced['file_content'] = str_replace($find, $replace, $original['file_content']);
		        
		        //$this->log->write('[powership] New content is: ' . $produced['file_content']);
		        
    		    /*
    		     * Renaming:
    		     */
		        ///var/www/opencart-demos/public/demo_oc2/system/powership_skel/powership_flat_oc2/skel/admin/controller/shipping/__LOWER_CASE_CODE__.php
		        $explosion = explode("/skel/", $original['file_absolute_path']);
		        $produced['file_absolute_path'] = str_replace($find, $replace, $explosion[1]);
		        
		        /*
		         * Output file to correct location
		         * Take care of admin/catalog folder that could have non standard names.
		         */
		        if($this->startsWith($produced['file_absolute_path'], 'admin/')){
		            $explosion = explode("admin/", $produced['file_absolute_path']);
		            
		            //$relativePath = $this->replace_or_not_for_oc23($explosion[1]);
		            $relativePath = $explosion[1];
		            
		            $produced['file_absolute_path'] = DIR_APPLICATION . $relativePath;
		            //$this->log->write('[powership] admin file will go to ' . $produced['file_absolute_path']);
		            
		        }else if ($this->startsWith($produced['file_absolute_path'], 'catalog/')){
		            $explosion = explode("catalog/", $produced['file_absolute_path']);
		            
		            //$relativePath = $this->replace_or_not_for_oc23($explosion[1]);
		            $relativePath = $explosion[1];
		            
		            $produced['file_absolute_path'] = DIR_CATALOG . $relativePath;
		            //$this->log->write('[powership] catalog file will go to ' . $produced['file_absolute_path']);
		            
		        }else{    //vqmod
		            $explosion = explode("vqmod/", $produced['file_absolute_path']);
		            $produced['file_absolute_path'] = dirname(DIR_APPLICATION) . '/vqmod/' . $explosion[1];
		            //$this->log->write('[powership] VQMOD file will go to ' . $produced['file_absolute_path']);
		            
		        }
		    
		        $myPath = dirname($produced['file_absolute_path']);
		        if(! file_exists($myPath)){
		            mkdir($myPath);
		        }
		        file_put_contents($produced['file_absolute_path'], $produced['file_content']);
		    }
		    
		    
		    /*
		     * Redirect to shipping
		     */
			
			$this->session->data['success'] = $this->language->get('text_success');
						
			if(version_compare(VERSION, '2.3.0.0') >= 0){
			    $this->response->redirect($this->url->link($modules_route, 'token=' . $this->session->data['token'] . '&type=shipping', 'SSL'));
			}else if(version_compare(VERSION, '2.2.0.0') >= 0){
    			$this->response->redirect($this->url->link('extension/shipping', 'token=' . $this->session->data['token'], true));
			}else{
    			$this->response->redirect($this->url->link('extension/shipping', 'token=' . $this->session->data['token'], 'SSL'));
			}
			
		}

		$text_strings = array(
			'heading_title',
			'text_enabled',
			'text_disabled',
			'text_left',
			'text_right',
			'text_home',
			'text_yes',
			'text_no',
			'button_save',
			'button_cancel'
		);
		
		foreach ($text_strings as $text) {
			$data[$text] = $this->language->get($text);
		}
		
		
		if(isset($this->session->data['error_msg']) && !empty($this->session->data['error_msg'])){
		   $this->error['warning'] = $this->session->data['error_msg'];
		   unset($this->session->data['error_msg']);
		}
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}


		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'href'      => $this->url->link('common/home', 'token=' . $this->session->data['token'], 'SSL'),
       		'text'      => $this->language->get('text_home'),
      		'separator' => FALSE
   		);

   		$data['breadcrumbs'][] = array(
   		        'href'      => $this->url->link($modules_route, 'token=' . $this->session->data['token'] . '&type=shipping', 'SSL'),
   		        'text'      => $this->language->get('text_module'),
	      		'separator' => ' :: '
   		);
   		
   		$data['breadcrumbs'][] = array(
   		        'href'      => $this->url->link($module_route, 'token=' . $this->session->data['token'], 'SSL'),
   		        'text'      => $this->language->get('heading_title'),
   		      		'separator' => ' :: '
   		);
   		
   		 
   		$data['action'] = $this->url->link($module_route, 'token=' . $this->session->data['token'] . '&type=shipping', 'SSL');
   		
   		$data['cancel'] = $this->url->link($modules_route, 'token=' . $this->session->data['token'] . '&type=shipping', 'SSL');
   		
		
		
		$config_data = array(
		);
		
		foreach ($config_data as $conf) {
		    if (isset($this->request->post[$conf])) {
		        $data[$conf] = $this->request->post[$conf];
		    } else {
		        $data[$conf] = $this->config->get($conf);
		    }
		}
		
		
		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');
		
		$this->response->setOutput($this->load->view('module/powership.tpl', $data));
	}
	
	public function delete(){
	    
	    if ($this->request->server['REQUEST_METHOD'] == 'POST') {
	        
	        $methodId = $this->request->post['method_id'];
	        $this->log->write('[powership] Delete action of method: ' . $methodId);
	        
	        //disable the method
	        
	        //remove the main file
            if(version_compare(VERSION, "2.3.0.0", "ge")){
                unlink(DIR_APPLICATION . "controller/extension/shipping/powership_" . $methodId . ".php");
            }else{
                unlink(DIR_APPLICATION . "controller/shipping/powership_" . $methodId . ".php");
            }

	    }
	    

// 	    $this->session->data['success'] = $this->language->get('text_success');
// 	    $this->session->data['success'] = $this->language->get('Method deleted successfully');
	    
// 	    $this->response->redirect($this->url->link('extension/shipping', 'token=' . $this->session->data['token'], true));
        if(version_compare(VERSION, "2.3.0.0", "ge")){
            $this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=shipping', true));
        }else{
            $this->response->redirect($this->url->link('extension/shipping/uninstall', 'token=' . $this->session->data['token'] . '&extension=powership_' . $methodId, true));
        }

    }
	
	private function replace_or_not_for_oc23($relativePath){
	    
	    if(version_compare(VERSION, "2.3.0.0", "ge")){
	        //$relativePath = str_replace("controller/shipping",     "controller/extension/shipping",     $relativePath);
	        //$relativePath = str_replace("language/en-gb/shipping", "language/en-gb/extension/shipping", $relativePath);
	        //$relativePath = str_replace("view/template/shipping",  "view/template/extension/shipping",  $relativePath);
            //$relativePath = str_replace("model/shipping",          "model/extension/shipping",          $relativePath);
	    }else{
	        $relativePath = $relativePath;
	    }
	    
	    return $relativePath;
	}
	
	
}