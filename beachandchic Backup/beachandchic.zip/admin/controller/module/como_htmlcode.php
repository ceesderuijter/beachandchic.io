<?php
class ControllerModuleComoHtmlCode extends Controller {
	private $error = array(); 
    private $module_info = array();

	public function index() {   
		$this->load->language('module/como_htmlcode');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('extension/module');
		$this->load->model('tool/image');
		$this->load->model('localisation/language');
		
		$data['languages'] = $this->model_localisation_language->getLanguages();
		
		if (isset($this->request->server['HTTPS']) && (($this->request->server['HTTPS'] == 'on') || ($this->request->server['HTTPS'] == '1'))) {
			$data['httpimagedir'] = HTTPS_CATALOG . 'image/';
		} else {
			$data['httpimagedir'] = HTTP_CATALOG . 'image/';
		}

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			if (!isset($this->request->get['module_id'])) {
				$this->model_extension_module->addModule('como_htmlcode', $this->request->post);
			} else {
				$this->model_extension_module->editModule($this->request->get['module_id'], $this->request->post);
			}
					
			$this->session->data['success'] = $this->language->get('text_success');
						
			$this->response->redirect($this->url->link('extension/module', 'token=' . $this->session->data['token'], true));
		}
				
		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_name_help'] = $this->language->get('entry_name_help');	
		$data['entry_border'] = $this->language->get('entry_border');		
		$data['entry_border_help'] = $this->language->get('entry_border_help');		
		$data['text_yes'] = $this->language->get('text_yes');
    	$data['text_no'] = $this->language->get('text_no');	
		$data['entry_setting'] = $this->language->get('entry_setting');
		$data['entry_status'] = $this->language->get('entry_status');
		$data['entry_html_block'] = $this->language->get('entry_html_block');
		$data['entry_html_code'] = $this->language->get('entry_html_code');
		$data['entry_html_code_help'] = $this->language->get('entry_html_code_help');
		$data['entry_img_block'] = $this->language->get('entry_img_block');
		$data['entry_template'] = $this->language->get('entry_template');
		$data['entry_template_help'] = $this->language->get('entry_template_help');
		$data['entry_stylesheet'] = $this->language->get('entry_stylesheet');
		$data['entry_stylesheet_help'] = $this->language->get('entry_stylesheet_help');
		$data['entry_img_number'] = $this->language->get('entry_img_number');
		$data['entry_img_number_help'] = $this->language->get('entry_img_number_help');
		$data['entry_background'] = $this->language->get('entry_background');
		$data['entry_background_help'] = $this->language->get('entry_background_help');
		$data['entry_number'] = $this->language->get('entry_number');
		$data['entry_image'] = $this->language->get('entry_image');
		$data['entry_image_help'] = $this->language->get('entry_image_help');	
		$data['entry_image1'] = $this->language->get('entry_image1');
		$data['entry_image1_help'] = $this->language->get('entry_image1_help');	
		$data['entry_link'] = $this->language->get('entry_link');
		$data['entry_link_help'] = $this->language->get('entry_link_help');
		$data['entry_title'] = $this->language->get('entry_title');
		$data['entry_title_help'] = $this->language->get('entry_title_help');
		$data['entry_html_editor_help'] = $this->language->get('entry_html_editor_help');
		$data['entry_html_editor'] = $this->language->get('entry_html_editor');
		$data['entry_block_title'] = $this->language->get('entry_block_title');
		$data['entry_block_title_help'] = $this->language->get('entry_block_title_help');
		$data['entry_block_link'] = $this->language->get('entry_block_link');
		$data['entry_block_link_help'] = $this->language->get('entry_block_link_help');
		$data['entry_title_image'] = $this->language->get('entry_title_image');
		$data['entry_title_image_help'] = $this->language->get('entry_title_image_help');
		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');
		$data['button_add_module'] = $this->language->get('button_add_module');
		$data['button_remove'] = $this->language->get('button_remove');
		$data['text_image_manager'] = $this->language->get('text_image_manager');	
		$data['token'] = $this->session->data['token'];
		$data['no_image'] = $this->model_tool_image->resize('no_image.png', 32, 32);
		
        // stylesheets in default theme
        $data['stylesheets_default'] = array();
        foreach (glob(DIR_CATALOG . 'view/theme/default/stylesheet/como_htmlcode*.css') as $filename) {
            $data['stylesheets_default'][] = basename($filename);
        }
		
        // templates in default theme
        $data['templates_img_block_default'] = array();
        foreach (glob(DIR_CATALOG . 'view/theme/default/template/module/como_imgblock_img*.tpl') as $filename) {
            $data['templates_img_block_default'][] = basename($filename);
        }
        
 		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}
		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

  		$data['breadcrumbs'] = array();

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_home'),
			'href'      => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true),
      		'separator' => false
   		);

   		$data['breadcrumbs'][] = array(
       		'text'      => $this->language->get('text_module'),
			'href'      => $this->url->link('extension/module', 'token=' . $this->session->data['token'], true)
   		);
		
		if (!isset($this->request->get['module_id'])) {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('module/como_htmlcode', 'token=' . $this->session->data['token'], true)
			);
		} else {
			$data['breadcrumbs'][] = array(
				'text' => $this->language->get('heading_title'),
				'href' => $this->url->link('module/como_htmlcode', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true)
			);
		}
		
		if (!isset($this->request->get['module_id'])) {
			$data['action'] = $this->url->link('module/como_htmlcode', 'token=' . $this->session->data['token'], true);
		} else {
			$data['action'] = $this->url->link('module/como_htmlcode', 'token=' . $this->session->data['token'] . '&module_id=' . $this->request->get['module_id'], true);
		}
		
		$data['cancel'] = $this->url->link('extension/module', 'token=' . $this->session->data['token'], true);

		if (isset($this->request->get['module_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$this->module_info = $this->model_extension_module->getModule($this->request->get['module_id']);
		}

		$data['name'] = $this->setData('name', '');
		$data['status'] = $this->setData('status', '1');
		$data['border'] = $this->setData('border', '1');
		$data['block_title'] = $this->setData('block_title', array());
		$data['block_link'] = $this->setData('block_link', '');
		$data['title_image'] = $this->setData('title_image', '');
		$data['stylesheet'] = $this->setData('stylesheet', 'como_htmlcode.css');
		$data['html_code_status'] = $this->setData('html_code_status', '');
		$data['html_visualeditor'] = $this->setData('html_visualeditor', '');
		$data['como_htmlcode'] = $this->setData('como_htmlcode', array());
		$data['img_block_status'] = $this->setData('img_block_status', '');
		$data['img_block_template'] = $this->setData('img_block_template', 'como_imgblock_img.tpl');
		$data['img_block_background'] = $this->setData('img_block_background', '');
		$data['img_number'] = $this->setData('img_number', 6);
		$data['img_block_images'] = $this->setData('img_block_images', array());
		$data['img_block_images1'] = $this->setData('img_block_images1', array());
		$data['img_block_links'] = $this->setData('img_block_links', array());
		$data['img_block_titles'] = $this->setData('img_block_titles', array());

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('module/como_htmlcode', $data));
	}

	private function setData($dataname, $defaultValue='') {
		if (isset($this->request->post[$dataname])) {
			return $this->request->post[$dataname];
		} elseif (isset($this->module_info[$dataname])) {
			return $this->module_info[$dataname];
		} else {
			return $defaultValue;
		}
    }

	private function validate() {
		if (!$this->user->hasPermission('modify', 'module/como_htmlcode')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 64)) {
			$this->error['name'] = $this->language->get('error_name');
		}
		
		return !$this->error;
	}
}
