<?php 

class ModelModulePowership extends Model {
    
}