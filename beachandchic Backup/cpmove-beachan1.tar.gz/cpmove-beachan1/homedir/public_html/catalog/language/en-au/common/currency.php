<?php
// Text
$_['text_currency'] = 'Currency';