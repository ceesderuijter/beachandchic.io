<?php
// Text
$_['text_home']          = 'Home';

$_['text_categories']    = 'category';
$_['text_products']      = 'Featured Products';
$_['text_cart']          = 'Add to Cart';
$_['text_whishlist']     = 'Add to Wish List';
$_['text_compare']       = 'Compare this Product';