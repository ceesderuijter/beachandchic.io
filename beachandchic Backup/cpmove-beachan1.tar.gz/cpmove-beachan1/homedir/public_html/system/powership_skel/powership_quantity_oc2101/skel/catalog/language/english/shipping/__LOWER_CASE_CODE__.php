<?php
// Text
$_['text_title']  = '__DISPLAY_NAME__';
$_['text_quantity'] = 'Quantity:';