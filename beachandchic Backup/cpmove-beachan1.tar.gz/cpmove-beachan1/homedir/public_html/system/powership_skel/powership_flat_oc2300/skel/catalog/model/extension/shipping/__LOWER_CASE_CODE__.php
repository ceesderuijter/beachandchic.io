<?php
class ModelExtensionShipping__CAMEL_CASE_CODE__ extends Model {
	function getQuote($address) {
		$this->load->language('extension/shipping/__LOWER_CASE_CODE__');

		$query = $this->db->query("SELECT * FROM " . DB_PREFIX . "zone_to_geo_zone WHERE geo_zone_id = '" . (int)$this->config->get('__LOWER_CASE_CODE___geo_zone_id') . "' AND country_id = '" . (int)$address['country_id'] . "' AND (zone_id = '" . (int)$address['zone_id'] . "' OR zone_id = '0')");

		if (!$this->config->get('__LOWER_CASE_CODE___geo_zone_id')) {
			$status = true;
		} elseif ($query->num_rows) {
			$status = true;
		} else {
			$status = false;
		}

		$method_data = array();

		if ($status) {
			$quote_data = array();

			$title = $this->language->get('text_description');
			
			//failsafe: no language in session when admin edit order.
			$cfg_descriptions = $this->config->get('__LOWER_CASE_CODE___descriptions');
			if(!empty($cfg_descriptions)){
			    if(isset($this->session->data['language']) && !empty($cfg_descriptions[$this->session->data['language']])){
			        $title = $cfg_descriptions[$this->session->data['language']];
			    }else{
			        $title = reset($cfg_descriptions);
			    }
			}
			
			$quote_data['__LOWER_CASE_CODE__'] = array(
				'code'         => '__LOWER_CASE_CODE__.__LOWER_CASE_CODE__',
				'title'        => $title,
				'cost'         => $this->config->get('__LOWER_CASE_CODE___cost'),
				'tax_class_id' => $this->config->get('__LOWER_CASE_CODE___tax_class_id'),
				'text'         => $this->currency->format($this->tax->calculate($this->config->get('__LOWER_CASE_CODE___cost'), $this->config->get('__LOWER_CASE_CODE___tax_class_id'), $this->config->get('config_tax')), $this->session->data['currency'])
			);

		
		    //failsafe: no language in session when admin edit order.
			$title = $this->language->get('text_title');
			$cfg_titles = $this->config->get('__LOWER_CASE_CODE___titles');
			if(!empty($cfg_titles)){
			    if(isset($this->session->data['language']) && !empty($cfg_titles[$this->session->data['language']])){
    			    $title = $cfg_titles[$this->session->data['language']];
			    }else{
			        $title = reset($cfg_titles);
			    }
			}
			
			
			$method_data = array(
				'code'       => '__LOWER_CASE_CODE__',
				'title'      => $title,
				'quote'      => $quote_data,
				'sort_order' => $this->config->get('__LOWER_CASE_CODE___sort_order'),
				'error'      => false
			);
		}

		
		//failsafe: no language in session when admin edit order.
		$cfg_additional_notes = $this->config->get('__LOWER_CASE_CODE___additional_notes');
		if($status && !empty($cfg_additional_notes)){
		    if(isset($this->session->data['language'])){
		        $additional_notes = $cfg_additional_notes[$this->session->data['language']];
		    }else{
		        $additional_notes = reset($cfg_additional_notes);
		    }
		    
		    //reported on oc22 at checkout, multiline not working
		    $method_data['powership_additional_note'] = nl2br($additional_notes);
		}
		
		return $method_data;
	}
}