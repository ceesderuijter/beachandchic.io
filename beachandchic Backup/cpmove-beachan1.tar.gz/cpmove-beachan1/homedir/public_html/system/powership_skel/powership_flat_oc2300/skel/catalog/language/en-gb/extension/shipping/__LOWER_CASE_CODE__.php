<?php
// Text
$_['text_title']       = '__DISPLAY_NAME__';
$_['text_description'] = '__DISPLAY_NAME__';