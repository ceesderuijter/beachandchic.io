<?php
// Heading
$_['heading_title']    = '__DISPLAY_NAME__';

// Text
$_['text_shipping']    = 'Shipping';
$_['text_success']     = 'Success: You have modified __DISPLAY_NAME__ shipping!';
$_['text_edit']        = 'Edit __DISPLAY_NAME__ Shipping. ID: __HASH_CODE__';

// Entry
$_['entry_title']       = 'Title';
$_['entry_description']       = 'Description';
$_['entry_cost']       = 'Cost';
$_['entry_tax_class']  = 'Tax Class';
$_['entry_geo_zone']   = 'Geo Zone';
$_['entry_status']     = 'Status';
$_['entry_sort_order'] = 'Sort Order';
$_['entry_additional_note'] = 'Additional note';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify __DISPLAY_NAME__ shipping!';
