<?php
namespace Session;
final class File {
	public $data = array();

	public function __construct() {

	}
}
